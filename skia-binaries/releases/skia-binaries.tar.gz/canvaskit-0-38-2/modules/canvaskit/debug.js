function Debug(msg) {
  console.warn(msg);
}
/** @const */ var IsDebug = true;
