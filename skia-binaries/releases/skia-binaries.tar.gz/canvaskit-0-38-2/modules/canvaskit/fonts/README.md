To generate the files (other than nofonts.cpp) in here:

    python tools/embed_resources.py --name SK_EMBEDDED_FONTS --input ~/Downloads/NotoMono-Regular.ttf --output modules/canvaskit/NotoMono-Regular.ttf.cpp --align 4
