This folder contains Typescript function definitions and documentation.

The goal will be to keep these up to date and contribute them to the
DefinitelyTyped project.
